﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ilaclar
{
    public partial class Default : System.Web.UI.Page
    {
        IlaclarEntities baglanti = new IlaclarEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEkle_Click(object sender, EventArgs e)
        {
            Ilaclar ilacEkle = new Ilaclar();

            ilacEkle.UrunKodu = int.Parse(tbxUrunKodu.Text);
            ilacEkle.UrunAdi = tbxUrunAdi.Text;
            ilacEkle.Fiyat = int.Parse(tbxFiyat.Text);
            ilacEkle.Stok = int.Parse(tbxStok.Text);
            ilacEkle.UrunAciklamasi = tbxUrunAciklama.Text;

            try
            {
                baglanti.Ilaclar.Add(ilacEkle);
                baglanti.SaveChanges();
                lblSonuc.Text = "Kayıt Başarılı";
            }
            catch (Exception)
            {
                lblSonuc.Text = "Kayıt Başarısız";
            }
        }

        protected void btnListele_Click(object sender, EventArgs e)
        {
            baglanti.Ilaclar.Load();
            GridView1.DataSource = baglanti.Ilaclar.Local;
            GridView1.DataBind();
        }

        protected void btnsil_Click(object sender, EventArgs e)
        {
            int urunkodu = int.Parse(tbxUrunKodu.Text);
            var sorgu = (from kayit in baglanti.Ilaclar
                         where kayit.UrunKodu == urunkodu
                         select kayit).ToList();

            if (sorgu.Count == 1)
            {
                baglanti.Ilaclar.Remove(sorgu[0]);
                baglanti.SaveChanges();
                lblSonuc.Text = "İlaç Başarıyla Silindi";
            }
            else
            {
                lblSonuc.Text = "Kayıt Bulunamadı";
            }
        }

        protected void btnGuncelle_Click(object sender, EventArgs e)
        {
            int urunKodu = Convert.ToInt32(tbxUrunKodu.Text);
            var sorgu = (from kayit in baglanti.Ilaclar
                         where kayit.UrunKodu == urunKodu
                         select kayit).ToList();
            if (sorgu.Count == 1)
            {
                sorgu[0].UrunAdi = tbxFiyat.Text;
                sorgu[0].Fiyat = int.Parse(tbxFiyat.Text);
                sorgu[0].Stok = int.Parse(tbxStok.Text);
                sorgu[0].UrunAciklamasi = tbxUrunAciklama.Text;
                baglanti.SaveChanges();
                lblSonuc.Text = "Kayıt Başarıyla Güncellendi";
            }
            else
            {
                lblSonuc.Text = "Kayıt Bulunamadı veya Güncellemede Hata Çıktı";
            }
        }
    }
}